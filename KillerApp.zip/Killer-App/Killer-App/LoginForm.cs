﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Killer_App
{
    public partial class LoginForm : Form
    {
        Database database;
        public LoginForm()
        {
            InitializeComponent();
            database = new Database();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = tbUsername.Text;
            string password = tbPassword.Text;

            User user = database.UserAuthenticate(username, password);

            if (user != null)
            {
                OpenSubjectsForm(user);
            }
            else
            {
                MessageBox.Show("Login failed");
            }
        }

        private void OpenSubjectsForm(User user)
        {
            Form subjectsForm = new SubjectsForm(user);
            subjectsForm.FormClosed += (s, args) => this.Close();
            subjectsForm.Show();
            this.Hide();
        }
    }
}
