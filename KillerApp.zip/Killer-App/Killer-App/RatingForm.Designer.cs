﻿namespace Killer_App
{
    partial class RatingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbRating = new System.Windows.Forms.TextBox();
            this.btnRate = new System.Windows.Forms.Button();
            this.btnDontRate = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tbRating
            // 
            this.tbRating.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbRating.Location = new System.Drawing.Point(89, 24);
            this.tbRating.Name = "tbRating";
            this.tbRating.Size = new System.Drawing.Size(62, 61);
            this.tbRating.TabIndex = 0;
            // 
            // btnRate
            // 
            this.btnRate.Location = new System.Drawing.Point(25, 100);
            this.btnRate.Name = "btnRate";
            this.btnRate.Size = new System.Drawing.Size(75, 48);
            this.btnRate.TabIndex = 1;
            this.btnRate.Text = "Rate";
            this.btnRate.UseVisualStyleBackColor = true;
            this.btnRate.Click += new System.EventHandler(this.btnRate_Click);
            // 
            // btnDontRate
            // 
            this.btnDontRate.Location = new System.Drawing.Point(143, 100);
            this.btnDontRate.Name = "btnDontRate";
            this.btnDontRate.Size = new System.Drawing.Size(75, 48);
            this.btnDontRate.TabIndex = 2;
            this.btnDontRate.Text = "Don\'t rate";
            this.btnDontRate.UseVisualStyleBackColor = true;
            this.btnDontRate.Click += new System.EventHandler(this.btnDontRate_Click);
            // 
            // RatingForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(246, 153);
            this.Controls.Add(this.btnDontRate);
            this.Controls.Add(this.btnRate);
            this.Controls.Add(this.tbRating);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "RatingForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RatingForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbRating;
        private System.Windows.Forms.Button btnRate;
        private System.Windows.Forms.Button btnDontRate;
    }
}