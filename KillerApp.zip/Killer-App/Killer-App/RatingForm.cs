﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Killer_App
{
    public partial class RatingForm : Form
    {
        Item selectedItem;
        Database database;
        public RatingForm(Item item)
        {
            InitializeComponent();
            selectedItem = item;
            database = new Database();
            
        }

        private void btnRate_Click(object sender, EventArgs e)
        {
            try
            {
                int rating = Convert.ToInt16(tbRating.Text);
            
                if (!(rating > 10 || rating < 1))
                {
                    database.RateItem(selectedItem, Convert.ToInt16(tbRating.Text));
                    this.Close();
                }

                else
                {
                    MessageBox.Show("Please choose a rating from 1 to 10");
                }
            }
            catch 
            {
                MessageBox.Show("Please only use numbers");
            }
        }

        private void btnDontRate_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
