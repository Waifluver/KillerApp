﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Killer_App
{
    public partial class ItemsForm : Form
    {
        Database database;
        User loggedInUser;
        Subject chosenSubject;
        public ItemsForm(User user, Subject subject)
        {
            InitializeComponent();
            database = new Database();

            loggedInUser = user;
            chosenSubject = subject;
            AddItemToList();
            AddImporantToList();
        }


        private void btnFilmAdd_Click(object sender, EventArgs e)
        {
            database.AddItem(tbFilmName.Text, tbFilmDirector.Text, tbFilmGenre.Text, Convert.ToInt32(tbFilmYear.Text), "film", chosenSubject, loggedInUser);
            ClearListViews();
            ClearTextBoxes("film");
            AddItemToList();
        }

        private void btnMusicAdd_Click(object sender, EventArgs e)
        {
            database.AddItem(tbMusicName.Text, tbMusicArtist.Text, tbMusicGenre.Text, Convert.ToInt32(tbMusicYear.Text), "music", chosenSubject, loggedInUser);
            ClearListViews();
            ClearTextBoxes("music");
            AddItemToList();
        }

        private void btnGamesAdd_Click(object sender, EventArgs e)
        {
            database.AddItem(tbGamesName.Text, tbGamesDev.Text, tbGamesGenre.Text, Convert.ToInt32(tbGamesYear.Text), "game", chosenSubject, loggedInUser);
            ClearListViews();
            ClearTextBoxes("games");
            AddItemToList();
        }

        private void btnLitComp_Click(object sender, EventArgs e)
        {
            CompleteItem(listViewLit);
        }

        private void btnFilm_Click(object sender, EventArgs e)
        {
            CompleteItem(listViewFilm);
        }

        private void btnMusicComp_Click(object sender, EventArgs e)
        {
            CompleteItem(listViewMusic);
        }

        private void btnGamesComp_Click(object sender, EventArgs e)
        {
            CompleteItem(listViewGames);
        }
        private void AddItemToList()
        {
            foreach (Item item in database.GetItems(loggedInUser.Id, chosenSubject))
            {
                switch (item.Sort)
                {
                    case "literature":
                        CreateItem(listViewLit, item);
                        break;
                    case "film":
                        CreateItem(listViewFilm, item);
                        break;
                    case "game":
                        CreateItem(listViewGames, item);
                        break;
                    case "music":
                        CreateItem(listViewMusic, item);
                        break;
                }
            }
        }

        private void CreateItem(ListView listView, Item item)
        {
            ListViewItem NewItem = new ListViewItem(item.Name);
            NewItem.SubItems.Add(item.Creator);
            NewItem.SubItems.Add(item.Genre);
            NewItem.SubItems.Add(item.Year.ToString());
            NewItem.SubItems.Add(5.ToString());
            NewItem.Tag = item;

            listView.Items.Add(NewItem);

            if (item.Completed == "true")
            {
                listView.Items[NewItem.Index].BackColor = Color.LawnGreen;
            }
        }

        private void ClearTextBoxes(string textBox)
        {
            switch (textBox)
            {
                case "literature":
                    tbLitName.Clear();
                    tbLitWriter.Clear();
                    tbLitGenre.Clear();
                    tbLitYear.Clear();
                    break;
                case "film":
                    tbFilmName.Clear();
                    tbFilmDirector.Clear();
                    tbFilmGenre.Clear();
                    tbFilmYear.Clear();
                    break;
                case "music":
                    tbMusicName.Clear();
                    tbMusicArtist.Clear();
                    tbMusicGenre.Clear();
                    tbMusicYear.Clear();
                    break;
                case "games":
                    tbGamesName.Clear();
                    tbGamesDev.Clear();
                    tbGamesGenre.Clear();
                    tbGamesYear.Clear();
                    break;
            }

        }

        void ClearListViews()
        {
            listViewLit.Items.Clear();
            listViewFilm.Items.Clear();
            listViewMusic.Items.Clear();
            listViewGames.Items.Clear();
        }
        void ResetListViews()
        {
            ClearListViews();
            listViewImp.Items.Clear();
            AddItemToList();
            AddImporantToList();
        }
        private void btnLitAdd_Click(object sender, EventArgs e)
        {
            database.AddItem(tbLitName.Text, tbLitWriter.Text, tbLitGenre.Text, Convert.ToInt32(tbLitYear.Text), "literature", chosenSubject, loggedInUser);
            ClearListViews();
            ClearTextBoxes("literature");
            AddItemToList();
        }
        private void CompleteItem(ListView listView)
        {
            if (listView.FocusedItem != null)
            {
                Item item = (Item)listView.FocusedItem.Tag;
                OpenRatingForm(item);
                database.CompleteItem(item);
                ResetListViews();
            }
        }

        private void OpenRatingForm(Item item)
        {
                Form ratingForm = new RatingForm(item);
                ratingForm.Show();
                ratingForm.FormClosed += (s, args) => ResetListViews(); ;
               
        }

        private void DeleteItem(ListView listView)
        {
            if (listView.FocusedItem != null)
            {
                Item item = (Item)listView.FocusedItem.Tag;
                if (listView != listViewImp)
                {
                    database.DeleteItem(item);
                    ClearListViews();
                    AddItemToList();
                }
                else
                {
                    database.DeleteImportantItem(item);
                    listViewImp.Items.Clear();
                    AddImporantToList();
                }
            }

        }

        private void AddItemToImportant(ListView listView, Subject subject)
        {
            if (listView.FocusedItem != null)
            {
                Item item = (Item)listView.FocusedItem.Tag;
                database.AddToImportant(item, subject);
                listViewImp.Items.Clear();
                AddImporantToList();
            }
            

        }

        private void AddImporantToList()
        {
            foreach (Item item in database.GetImportantItems(chosenSubject))
            {
                CreateItem(listViewImp, item);
            }
        }

        private void btnLitDelete_Click(object sender, EventArgs e)
        {
            DeleteItem(listViewLit);
        }

        private void btnFilmDelete_Click(object sender, EventArgs e)
        {
            DeleteItem(listViewFilm);
        }

        private void btnMusicDelete_Click(object sender, EventArgs e)
        {
            DeleteItem(listViewMusic);
        }

        private void btnGamesDelete_Click(object sender, EventArgs e)
        {
            DeleteItem(listViewGames);
        }

        private void btnLitImp_Click(object sender, EventArgs e)
        {
            AddItemToImportant(listViewLit, chosenSubject);
        }

        private void btnFilmImp_Click(object sender, EventArgs e)
        {
            AddItemToImportant(listViewFilm, chosenSubject);
        }

        private void btnMusImp_Click(object sender, EventArgs e)
        {
            AddItemToImportant(listViewMusic, chosenSubject);
        }

        private void btnGamesImp_Click(object sender, EventArgs e)
        {
            AddItemToImportant(listViewGames, chosenSubject);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DeleteItem(listViewImp);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CompleteItem(listViewImp);
        }
    }
}
