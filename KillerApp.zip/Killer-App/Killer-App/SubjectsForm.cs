﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Killer_App
{
    public partial class SubjectsForm : Form
    {
        Database database;
        User loggedInUser;
        List<Subject> subjects;
        public SubjectsForm(User user)
        {
            InitializeComponent();
            database = new Database();

            loggedInUser = user;
            subjects = database.GetSubjects(loggedInUser.Id);
            AddSubjectsToList(subjects);
        }

       

        private void AddSubjectsToList(List<Subject> subjects)
        {
            foreach (Subject subject in subjects)
            {
                
                lbSubjects.Items.Add(subject.Name);
                
            }
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {

            Subject chosenSubject;
            int selectedIndex;

            if (lbSubjects.SelectedItem != null)
            {
                selectedIndex = lbSubjects.SelectedIndex;
                chosenSubject = database.GetSubjects(loggedInUser.Id)[selectedIndex];

                Form itemsForm = new ItemsForm(loggedInUser, chosenSubject);
                itemsForm.FormClosed += (s, args) => this.Close();
                itemsForm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Please select a subject");
            }
        }

       

        private void tbAddSubject_KeyDown(object sender, KeyEventArgs e)
        {
            string insertedSubject = tbAddSubject.Text;
            if(e.KeyCode == Keys.Enter)
            {
                if (insertedSubject != "" || insertedSubject != null)
                {
                    if (database.AddSubject(loggedInUser.Id, tbAddSubject.Text))
                    {
                        lbSubjects.Items.Clear();
                        AddSubjectsToList(database.GetSubjects(loggedInUser.Id));
                        tbAddSubject.Text = "";
                    }
                    else
                    {
                        MessageBox.Show("Subject already exists.");
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a subject");
                }
            }
        }

        private void btnSubjectDelet_Click(object sender, EventArgs e)
        {
           

            if (lbSubjects.SelectedItem != null)
            {
                database.DeleteSubject(lbSubjects.SelectedItem.ToString());
                lbSubjects.Items.Clear();
                AddSubjectsToList(database.GetSubjects(loggedInUser.Id));
            }
            else
            {
                MessageBox.Show("Please select a subject to delete");
            }
           
        }
    }
}

