﻿namespace Killer_App
{
    partial class SubjectsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbSubjects = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbAddSubject = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.btnSubjectDelet = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbSubjects
            // 
            this.lbSubjects.FormattingEnabled = true;
            this.lbSubjects.ItemHeight = 16;
            this.lbSubjects.Location = new System.Drawing.Point(81, 32);
            this.lbSubjects.Name = "lbSubjects";
            this.lbSubjects.Size = new System.Drawing.Size(177, 228);
            this.lbSubjects.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(86, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(162, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Choose your subject";
            // 
            // tbAddSubject
            // 
            this.tbAddSubject.Location = new System.Drawing.Point(81, 360);
            this.tbAddSubject.Name = "tbAddSubject";
            this.tbAddSubject.Size = new System.Drawing.Size(177, 22);
            this.tbAddSubject.TabIndex = 2;
            this.tbAddSubject.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbAddSubject_KeyDown);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(78, 340);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Add subject:";
            // 
            // btnConfirm
            // 
            this.btnConfirm.Location = new System.Drawing.Point(81, 266);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(177, 32);
            this.btnConfirm.TabIndex = 6;
            this.btnConfirm.Text = "Confirm subject";
            this.btnConfirm.UseVisualStyleBackColor = true;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // btnSubjectDelet
            // 
            this.btnSubjectDelet.Location = new System.Drawing.Point(81, 304);
            this.btnSubjectDelet.Name = "btnSubjectDelet";
            this.btnSubjectDelet.Size = new System.Drawing.Size(177, 33);
            this.btnSubjectDelet.TabIndex = 7;
            this.btnSubjectDelet.Text = "Delete subject";
            this.btnSubjectDelet.UseVisualStyleBackColor = true;
            this.btnSubjectDelet.Click += new System.EventHandler(this.btnSubjectDelet_Click);
            // 
            // SubjectsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(332, 397);
            this.Controls.Add(this.btnSubjectDelet);
            this.Controls.Add(this.btnConfirm);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbAddSubject);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbSubjects);
            this.Name = "SubjectsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SubjectsForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lbSubjects;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbAddSubject;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.Button btnSubjectDelet;
    }
}