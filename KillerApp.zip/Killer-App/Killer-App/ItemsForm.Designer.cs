﻿namespace Killer_App
{
    partial class ItemsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPageImportant = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.listViewImp = new System.Windows.Forms.ListView();
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader15 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader16 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPageLit = new System.Windows.Forms.TabPage();
            this.btnLitImp = new System.Windows.Forms.Button();
            this.btnLitDelete = new System.Windows.Forms.Button();
            this.btnLitComp = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.listViewLit = new System.Windows.Forms.ListView();
            this.columnName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Writer = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Period = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnYear = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnRating = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnLitAdd = new System.Windows.Forms.Button();
            this.tbLitYear = new System.Windows.Forms.TextBox();
            this.tbLitGenre = new System.Windows.Forms.TextBox();
            this.tbLitWriter = new System.Windows.Forms.TextBox();
            this.tbLitName = new System.Windows.Forms.TextBox();
            this.tabPageFilm = new System.Windows.Forms.TabPage();
            this.btnFilmImp = new System.Windows.Forms.Button();
            this.btnFilmDelete = new System.Windows.Forms.Button();
            this.btnFilm = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnFilmAdd = new System.Windows.Forms.Button();
            this.tbFilmYear = new System.Windows.Forms.TextBox();
            this.tbFilmGenre = new System.Windows.Forms.TextBox();
            this.tbFilmDirector = new System.Windows.Forms.TextBox();
            this.tbFilmName = new System.Windows.Forms.TextBox();
            this.listViewFilm = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPageMusic = new System.Windows.Forms.TabPage();
            this.btnMusImp = new System.Windows.Forms.Button();
            this.btnMusicDelete = new System.Windows.Forms.Button();
            this.btnMusicComp = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnMusicAdd = new System.Windows.Forms.Button();
            this.tbMusicYear = new System.Windows.Forms.TextBox();
            this.tbMusicGenre = new System.Windows.Forms.TextBox();
            this.tbMusicArtist = new System.Windows.Forms.TextBox();
            this.tbMusicName = new System.Windows.Forms.TextBox();
            this.listViewMusic = new System.Windows.Forms.ListView();
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPageGames = new System.Windows.Forms.TabPage();
            this.btnGamesImp = new System.Windows.Forms.Button();
            this.btnGamesDelete = new System.Windows.Forms.Button();
            this.btnGamesComp = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tbGamesYear = new System.Windows.Forms.TextBox();
            this.btnGamesAdd = new System.Windows.Forms.Button();
            this.tbGamesGenre = new System.Windows.Forms.TextBox();
            this.tbGamesDev = new System.Windows.Forms.TextBox();
            this.tbGamesName = new System.Windows.Forms.TextBox();
            this.listViewGames = new System.Windows.Forms.ListView();
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabControl1.SuspendLayout();
            this.tabPageImportant.SuspendLayout();
            this.tabPageLit.SuspendLayout();
            this.tabPageFilm.SuspendLayout();
            this.tabPageMusic.SuspendLayout();
            this.tabPageGames.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPageImportant);
            this.tabControl1.Controls.Add(this.tabPageLit);
            this.tabControl1.Controls.Add(this.tabPageFilm);
            this.tabControl1.Controls.Add(this.tabPageMusic);
            this.tabControl1.Controls.Add(this.tabPageGames);
            this.tabControl1.Location = new System.Drawing.Point(12, 11);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(776, 449);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPageImportant
            // 
            this.tabPageImportant.Controls.Add(this.button1);
            this.tabPageImportant.Controls.Add(this.btnDelete);
            this.tabPageImportant.Controls.Add(this.label17);
            this.tabPageImportant.Controls.Add(this.listViewImp);
            this.tabPageImportant.Location = new System.Drawing.Point(4, 25);
            this.tabPageImportant.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPageImportant.Name = "tabPageImportant";
            this.tabPageImportant.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPageImportant.Size = new System.Drawing.Size(768, 420);
            this.tabPageImportant.TabIndex = 4;
            this.tabPageImportant.Text = "Important";
            this.tabPageImportant.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(615, 18);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(124, 28);
            this.button1.TabIndex = 12;
            this.button1.Text = "Complete";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(615, 53);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(124, 32);
            this.btnDelete.TabIndex = 9;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(21, 12);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(185, 32);
            this.label17.TabIndex = 8;
            this.label17.Text = "Important items";
            // 
            // listViewImp
            // 
            this.listViewImp.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader13,
            this.columnHeader14,
            this.columnHeader15,
            this.columnHeader16});
            this.listViewImp.FullRowSelect = true;
            this.listViewImp.GridLines = true;
            this.listViewImp.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.listViewImp.Location = new System.Drawing.Point(27, 92);
            this.listViewImp.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.listViewImp.Name = "listViewImp";
            this.listViewImp.Scrollable = false;
            this.listViewImp.Size = new System.Drawing.Size(712, 307);
            this.listViewImp.TabIndex = 7;
            this.listViewImp.UseCompatibleStateImageBehavior = false;
            this.listViewImp.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "Name";
            this.columnHeader13.Width = 206;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "Creator";
            this.columnHeader14.Width = 177;
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "Period/Genre";
            this.columnHeader15.Width = 107;
            // 
            // columnHeader16
            // 
            this.columnHeader16.Text = "Year";
            this.columnHeader16.Width = 82;
            // 
            // tabPageLit
            // 
            this.tabPageLit.Controls.Add(this.btnLitImp);
            this.tabPageLit.Controls.Add(this.btnLitDelete);
            this.tabPageLit.Controls.Add(this.btnLitComp);
            this.tabPageLit.Controls.Add(this.label4);
            this.tabPageLit.Controls.Add(this.label3);
            this.tabPageLit.Controls.Add(this.label2);
            this.tabPageLit.Controls.Add(this.label1);
            this.tabPageLit.Controls.Add(this.listViewLit);
            this.tabPageLit.Controls.Add(this.btnLitAdd);
            this.tabPageLit.Controls.Add(this.tbLitYear);
            this.tabPageLit.Controls.Add(this.tbLitGenre);
            this.tabPageLit.Controls.Add(this.tbLitWriter);
            this.tabPageLit.Controls.Add(this.tbLitName);
            this.tabPageLit.Location = new System.Drawing.Point(4, 25);
            this.tabPageLit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPageLit.Name = "tabPageLit";
            this.tabPageLit.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPageLit.Size = new System.Drawing.Size(768, 420);
            this.tabPageLit.TabIndex = 0;
            this.tabPageLit.Text = "Literature";
            this.tabPageLit.UseVisualStyleBackColor = true;
            // 
            // btnLitImp
            // 
            this.btnLitImp.Location = new System.Drawing.Point(619, 11);
            this.btnLitImp.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLitImp.Name = "btnLitImp";
            this.btnLitImp.Size = new System.Drawing.Size(124, 28);
            this.btnLitImp.TabIndex = 13;
            this.btnLitImp.Text = "Add to important";
            this.btnLitImp.UseVisualStyleBackColor = true;
            this.btnLitImp.Click += new System.EventHandler(this.btnLitImp_Click);
            // 
            // btnLitDelete
            // 
            this.btnLitDelete.Location = new System.Drawing.Point(619, 39);
            this.btnLitDelete.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLitDelete.Name = "btnLitDelete";
            this.btnLitDelete.Size = new System.Drawing.Size(124, 28);
            this.btnLitDelete.TabIndex = 12;
            this.btnLitDelete.Text = "Delete";
            this.btnLitDelete.UseVisualStyleBackColor = true;
            this.btnLitDelete.Click += new System.EventHandler(this.btnLitDelete_Click);
            // 
            // btnLitComp
            // 
            this.btnLitComp.Location = new System.Drawing.Point(619, 69);
            this.btnLitComp.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLitComp.Name = "btnLitComp";
            this.btnLitComp.Size = new System.Drawing.Size(124, 28);
            this.btnLitComp.TabIndex = 11;
            this.btnLitComp.Text = "Complete";
            this.btnLitComp.UseVisualStyleBackColor = true;
            this.btnLitComp.Click += new System.EventHandler(this.btnLitComp_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(449, 84);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 17);
            this.label4.TabIndex = 10;
            this.label4.Text = "Year:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(308, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 17);
            this.label3.TabIndex = 9;
            this.label3.Text = "Genre/Period:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(167, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 17);
            this.label2.TabIndex = 8;
            this.label2.Text = "Writer:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 84);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 17);
            this.label1.TabIndex = 7;
            this.label1.Text = "Name:";
            // 
            // listViewLit
            // 
            this.listViewLit.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnName,
            this.Writer,
            this.Period,
            this.columnYear,
            this.columnRating});
            this.listViewLit.FullRowSelect = true;
            this.listViewLit.GridLines = true;
            this.listViewLit.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.listViewLit.Location = new System.Drawing.Point(28, 134);
            this.listViewLit.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.listViewLit.Name = "listViewLit";
            this.listViewLit.Scrollable = false;
            this.listViewLit.Size = new System.Drawing.Size(712, 270);
            this.listViewLit.TabIndex = 6;
            this.listViewLit.UseCompatibleStateImageBehavior = false;
            this.listViewLit.View = System.Windows.Forms.View.Details;
            // 
            // columnName
            // 
            this.columnName.Text = "Name";
            this.columnName.Width = 206;
            // 
            // Writer
            // 
            this.Writer.Text = "Writer";
            this.Writer.Width = 150;
            // 
            // Period
            // 
            this.Period.Text = "Period";
            this.Period.Width = 100;
            // 
            // columnYear
            // 
            this.columnYear.Text = "Year";
            this.columnYear.Width = 82;
            // 
            // columnRating
            // 
            this.columnRating.Text = "Rating";
            this.columnRating.Width = 61;
            // 
            // btnLitAdd
            // 
            this.btnLitAdd.Location = new System.Drawing.Point(619, 98);
            this.btnLitAdd.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLitAdd.Name = "btnLitAdd";
            this.btnLitAdd.Size = new System.Drawing.Size(124, 28);
            this.btnLitAdd.TabIndex = 5;
            this.btnLitAdd.Text = "Add";
            this.btnLitAdd.UseVisualStyleBackColor = true;
            this.btnLitAdd.Click += new System.EventHandler(this.btnLitAdd_Click);
            // 
            // tbLitYear
            // 
            this.tbLitYear.Location = new System.Drawing.Point(451, 103);
            this.tbLitYear.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbLitYear.Name = "tbLitYear";
            this.tbLitYear.Size = new System.Drawing.Size(132, 22);
            this.tbLitYear.TabIndex = 4;
            // 
            // tbLitGenre
            // 
            this.tbLitGenre.Location = new System.Drawing.Point(309, 103);
            this.tbLitGenre.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbLitGenre.Name = "tbLitGenre";
            this.tbLitGenre.Size = new System.Drawing.Size(132, 22);
            this.tbLitGenre.TabIndex = 3;
            // 
            // tbLitWriter
            // 
            this.tbLitWriter.Location = new System.Drawing.Point(169, 103);
            this.tbLitWriter.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbLitWriter.Name = "tbLitWriter";
            this.tbLitWriter.Size = new System.Drawing.Size(132, 22);
            this.tbLitWriter.TabIndex = 2;
            // 
            // tbLitName
            // 
            this.tbLitName.Location = new System.Drawing.Point(28, 103);
            this.tbLitName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbLitName.Name = "tbLitName";
            this.tbLitName.Size = new System.Drawing.Size(132, 22);
            this.tbLitName.TabIndex = 1;
            // 
            // tabPageFilm
            // 
            this.tabPageFilm.Controls.Add(this.btnFilmImp);
            this.tabPageFilm.Controls.Add(this.btnFilmDelete);
            this.tabPageFilm.Controls.Add(this.btnFilm);
            this.tabPageFilm.Controls.Add(this.label14);
            this.tabPageFilm.Controls.Add(this.label9);
            this.tabPageFilm.Controls.Add(this.label8);
            this.tabPageFilm.Controls.Add(this.label5);
            this.tabPageFilm.Controls.Add(this.btnFilmAdd);
            this.tabPageFilm.Controls.Add(this.tbFilmYear);
            this.tabPageFilm.Controls.Add(this.tbFilmGenre);
            this.tabPageFilm.Controls.Add(this.tbFilmDirector);
            this.tabPageFilm.Controls.Add(this.tbFilmName);
            this.tabPageFilm.Controls.Add(this.listViewFilm);
            this.tabPageFilm.Location = new System.Drawing.Point(4, 25);
            this.tabPageFilm.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPageFilm.Name = "tabPageFilm";
            this.tabPageFilm.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPageFilm.Size = new System.Drawing.Size(768, 420);
            this.tabPageFilm.TabIndex = 1;
            this.tabPageFilm.Text = "Film";
            this.tabPageFilm.UseVisualStyleBackColor = true;
            // 
            // btnFilmImp
            // 
            this.btnFilmImp.Location = new System.Drawing.Point(619, 11);
            this.btnFilmImp.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnFilmImp.Name = "btnFilmImp";
            this.btnFilmImp.Size = new System.Drawing.Size(124, 28);
            this.btnFilmImp.TabIndex = 19;
            this.btnFilmImp.Text = "Add to important";
            this.btnFilmImp.UseVisualStyleBackColor = true;
            this.btnFilmImp.Click += new System.EventHandler(this.btnFilmImp_Click);
            // 
            // btnFilmDelete
            // 
            this.btnFilmDelete.Location = new System.Drawing.Point(619, 39);
            this.btnFilmDelete.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnFilmDelete.Name = "btnFilmDelete";
            this.btnFilmDelete.Size = new System.Drawing.Size(124, 28);
            this.btnFilmDelete.TabIndex = 18;
            this.btnFilmDelete.Text = "Delete";
            this.btnFilmDelete.UseVisualStyleBackColor = true;
            this.btnFilmDelete.Click += new System.EventHandler(this.btnFilmDelete_Click);
            // 
            // btnFilm
            // 
            this.btnFilm.Location = new System.Drawing.Point(619, 69);
            this.btnFilm.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnFilm.Name = "btnFilm";
            this.btnFilm.Size = new System.Drawing.Size(124, 28);
            this.btnFilm.TabIndex = 17;
            this.btnFilm.Text = "Complete";
            this.btnFilm.UseVisualStyleBackColor = true;
            this.btnFilm.Click += new System.EventHandler(this.btnFilm_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(165, 84);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(62, 17);
            this.label14.TabIndex = 16;
            this.label14.Text = "Director:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(449, 84);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(42, 17);
            this.label9.TabIndex = 15;
            this.label9.Text = "Year:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(308, 84);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(97, 17);
            this.label8.TabIndex = 14;
            this.label8.Text = "Genre/Period:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(27, 84);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 17);
            this.label5.TabIndex = 13;
            this.label5.Text = "Name:";
            // 
            // btnFilmAdd
            // 
            this.btnFilmAdd.Location = new System.Drawing.Point(619, 98);
            this.btnFilmAdd.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnFilmAdd.Name = "btnFilmAdd";
            this.btnFilmAdd.Size = new System.Drawing.Size(124, 28);
            this.btnFilmAdd.TabIndex = 12;
            this.btnFilmAdd.Text = "Add";
            this.btnFilmAdd.UseVisualStyleBackColor = true;
            this.btnFilmAdd.Click += new System.EventHandler(this.btnFilmAdd_Click);
            // 
            // tbFilmYear
            // 
            this.tbFilmYear.Location = new System.Drawing.Point(451, 103);
            this.tbFilmYear.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbFilmYear.Name = "tbFilmYear";
            this.tbFilmYear.Size = new System.Drawing.Size(132, 22);
            this.tbFilmYear.TabIndex = 11;
            // 
            // tbFilmGenre
            // 
            this.tbFilmGenre.Location = new System.Drawing.Point(309, 103);
            this.tbFilmGenre.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbFilmGenre.Name = "tbFilmGenre";
            this.tbFilmGenre.Size = new System.Drawing.Size(132, 22);
            this.tbFilmGenre.TabIndex = 10;
            // 
            // tbFilmDirector
            // 
            this.tbFilmDirector.Location = new System.Drawing.Point(169, 103);
            this.tbFilmDirector.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbFilmDirector.Name = "tbFilmDirector";
            this.tbFilmDirector.Size = new System.Drawing.Size(132, 22);
            this.tbFilmDirector.TabIndex = 9;
            // 
            // tbFilmName
            // 
            this.tbFilmName.Location = new System.Drawing.Point(28, 103);
            this.tbFilmName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbFilmName.Name = "tbFilmName";
            this.tbFilmName.Size = new System.Drawing.Size(132, 22);
            this.tbFilmName.TabIndex = 8;
            // 
            // listViewFilm
            // 
            this.listViewFilm.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4});
            this.listViewFilm.FullRowSelect = true;
            this.listViewFilm.GridLines = true;
            this.listViewFilm.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.listViewFilm.Location = new System.Drawing.Point(28, 134);
            this.listViewFilm.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.listViewFilm.Name = "listViewFilm";
            this.listViewFilm.Scrollable = false;
            this.listViewFilm.Size = new System.Drawing.Size(712, 270);
            this.listViewFilm.TabIndex = 7;
            this.listViewFilm.UseCompatibleStateImageBehavior = false;
            this.listViewFilm.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Name";
            this.columnHeader1.Width = 206;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Director";
            this.columnHeader2.Width = 177;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Genre";
            this.columnHeader3.Width = 107;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Year";
            this.columnHeader4.Width = 82;
            // 
            // tabPageMusic
            // 
            this.tabPageMusic.Controls.Add(this.btnMusImp);
            this.tabPageMusic.Controls.Add(this.btnMusicDelete);
            this.tabPageMusic.Controls.Add(this.btnMusicComp);
            this.tabPageMusic.Controls.Add(this.label15);
            this.tabPageMusic.Controls.Add(this.label12);
            this.tabPageMusic.Controls.Add(this.label10);
            this.tabPageMusic.Controls.Add(this.label6);
            this.tabPageMusic.Controls.Add(this.btnMusicAdd);
            this.tabPageMusic.Controls.Add(this.tbMusicYear);
            this.tabPageMusic.Controls.Add(this.tbMusicGenre);
            this.tabPageMusic.Controls.Add(this.tbMusicArtist);
            this.tabPageMusic.Controls.Add(this.tbMusicName);
            this.tabPageMusic.Controls.Add(this.listViewMusic);
            this.tabPageMusic.Location = new System.Drawing.Point(4, 25);
            this.tabPageMusic.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPageMusic.Name = "tabPageMusic";
            this.tabPageMusic.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPageMusic.Size = new System.Drawing.Size(768, 420);
            this.tabPageMusic.TabIndex = 2;
            this.tabPageMusic.Text = "Music";
            this.tabPageMusic.UseVisualStyleBackColor = true;
            // 
            // btnMusImp
            // 
            this.btnMusImp.Location = new System.Drawing.Point(619, 11);
            this.btnMusImp.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMusImp.Name = "btnMusImp";
            this.btnMusImp.Size = new System.Drawing.Size(124, 28);
            this.btnMusImp.TabIndex = 24;
            this.btnMusImp.Text = "Add to important";
            this.btnMusImp.UseVisualStyleBackColor = true;
            this.btnMusImp.Click += new System.EventHandler(this.btnMusImp_Click);
            // 
            // btnMusicDelete
            // 
            this.btnMusicDelete.Location = new System.Drawing.Point(619, 39);
            this.btnMusicDelete.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMusicDelete.Name = "btnMusicDelete";
            this.btnMusicDelete.Size = new System.Drawing.Size(124, 28);
            this.btnMusicDelete.TabIndex = 23;
            this.btnMusicDelete.Text = "Delete";
            this.btnMusicDelete.UseVisualStyleBackColor = true;
            this.btnMusicDelete.Click += new System.EventHandler(this.btnMusicDelete_Click);
            // 
            // btnMusicComp
            // 
            this.btnMusicComp.Location = new System.Drawing.Point(619, 69);
            this.btnMusicComp.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMusicComp.Name = "btnMusicComp";
            this.btnMusicComp.Size = new System.Drawing.Size(124, 28);
            this.btnMusicComp.TabIndex = 22;
            this.btnMusicComp.Text = "Complete";
            this.btnMusicComp.UseVisualStyleBackColor = true;
            this.btnMusicComp.Click += new System.EventHandler(this.btnMusicComp_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(165, 84);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(44, 17);
            this.label15.TabIndex = 21;
            this.label15.Text = "Artist:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(308, 84);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(52, 17);
            this.label12.TabIndex = 20;
            this.label12.Text = "Genre:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(449, 84);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(42, 17);
            this.label10.TabIndex = 19;
            this.label10.Text = "Year:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(27, 84);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 17);
            this.label6.TabIndex = 18;
            this.label6.Text = "Name:";
            // 
            // btnMusicAdd
            // 
            this.btnMusicAdd.Location = new System.Drawing.Point(619, 98);
            this.btnMusicAdd.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMusicAdd.Name = "btnMusicAdd";
            this.btnMusicAdd.Size = new System.Drawing.Size(124, 28);
            this.btnMusicAdd.TabIndex = 17;
            this.btnMusicAdd.Text = "Add";
            this.btnMusicAdd.UseVisualStyleBackColor = true;
            this.btnMusicAdd.Click += new System.EventHandler(this.btnMusicAdd_Click);
            // 
            // tbMusicYear
            // 
            this.tbMusicYear.Location = new System.Drawing.Point(451, 103);
            this.tbMusicYear.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbMusicYear.Name = "tbMusicYear";
            this.tbMusicYear.Size = new System.Drawing.Size(132, 22);
            this.tbMusicYear.TabIndex = 16;
            // 
            // tbMusicGenre
            // 
            this.tbMusicGenre.Location = new System.Drawing.Point(309, 103);
            this.tbMusicGenre.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbMusicGenre.Name = "tbMusicGenre";
            this.tbMusicGenre.Size = new System.Drawing.Size(132, 22);
            this.tbMusicGenre.TabIndex = 15;
            // 
            // tbMusicArtist
            // 
            this.tbMusicArtist.Location = new System.Drawing.Point(169, 103);
            this.tbMusicArtist.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbMusicArtist.Name = "tbMusicArtist";
            this.tbMusicArtist.Size = new System.Drawing.Size(132, 22);
            this.tbMusicArtist.TabIndex = 14;
            // 
            // tbMusicName
            // 
            this.tbMusicName.Location = new System.Drawing.Point(28, 103);
            this.tbMusicName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbMusicName.Name = "tbMusicName";
            this.tbMusicName.Size = new System.Drawing.Size(132, 22);
            this.tbMusicName.TabIndex = 13;
            // 
            // listViewMusic
            // 
            this.listViewMusic.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8});
            this.listViewMusic.FullRowSelect = true;
            this.listViewMusic.GridLines = true;
            this.listViewMusic.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.listViewMusic.Location = new System.Drawing.Point(28, 134);
            this.listViewMusic.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.listViewMusic.Name = "listViewMusic";
            this.listViewMusic.Scrollable = false;
            this.listViewMusic.Size = new System.Drawing.Size(712, 270);
            this.listViewMusic.TabIndex = 8;
            this.listViewMusic.UseCompatibleStateImageBehavior = false;
            this.listViewMusic.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Name";
            this.columnHeader5.Width = 206;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Artist";
            this.columnHeader6.Width = 177;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Genre";
            this.columnHeader7.Width = 107;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Year";
            this.columnHeader8.Width = 82;
            // 
            // tabPageGames
            // 
            this.tabPageGames.Controls.Add(this.btnGamesImp);
            this.tabPageGames.Controls.Add(this.btnGamesDelete);
            this.tabPageGames.Controls.Add(this.btnGamesComp);
            this.tabPageGames.Controls.Add(this.label16);
            this.tabPageGames.Controls.Add(this.label13);
            this.tabPageGames.Controls.Add(this.label11);
            this.tabPageGames.Controls.Add(this.label7);
            this.tabPageGames.Controls.Add(this.tbGamesYear);
            this.tabPageGames.Controls.Add(this.btnGamesAdd);
            this.tabPageGames.Controls.Add(this.tbGamesGenre);
            this.tabPageGames.Controls.Add(this.tbGamesDev);
            this.tabPageGames.Controls.Add(this.tbGamesName);
            this.tabPageGames.Controls.Add(this.listViewGames);
            this.tabPageGames.Location = new System.Drawing.Point(4, 25);
            this.tabPageGames.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPageGames.Name = "tabPageGames";
            this.tabPageGames.Size = new System.Drawing.Size(768, 420);
            this.tabPageGames.TabIndex = 3;
            this.tabPageGames.Text = "Games";
            this.tabPageGames.UseVisualStyleBackColor = true;
            // 
            // btnGamesImp
            // 
            this.btnGamesImp.Location = new System.Drawing.Point(619, 11);
            this.btnGamesImp.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnGamesImp.Name = "btnGamesImp";
            this.btnGamesImp.Size = new System.Drawing.Size(124, 28);
            this.btnGamesImp.TabIndex = 25;
            this.btnGamesImp.Text = "Add to important";
            this.btnGamesImp.UseVisualStyleBackColor = true;
            this.btnGamesImp.Click += new System.EventHandler(this.btnGamesImp_Click);
            // 
            // btnGamesDelete
            // 
            this.btnGamesDelete.Location = new System.Drawing.Point(619, 39);
            this.btnGamesDelete.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnGamesDelete.Name = "btnGamesDelete";
            this.btnGamesDelete.Size = new System.Drawing.Size(124, 28);
            this.btnGamesDelete.TabIndex = 24;
            this.btnGamesDelete.Text = "Delete";
            this.btnGamesDelete.UseVisualStyleBackColor = true;
            this.btnGamesDelete.Click += new System.EventHandler(this.btnGamesDelete_Click);
            // 
            // btnGamesComp
            // 
            this.btnGamesComp.Location = new System.Drawing.Point(619, 69);
            this.btnGamesComp.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnGamesComp.Name = "btnGamesComp";
            this.btnGamesComp.Size = new System.Drawing.Size(124, 28);
            this.btnGamesComp.TabIndex = 23;
            this.btnGamesComp.Text = "Complete";
            this.btnGamesComp.UseVisualStyleBackColor = true;
            this.btnGamesComp.Click += new System.EventHandler(this.btnGamesComp_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(165, 84);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(77, 17);
            this.label16.TabIndex = 22;
            this.label16.Text = "Developer:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(308, 84);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(52, 17);
            this.label13.TabIndex = 21;
            this.label13.Text = "Genre:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(449, 84);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(42, 17);
            this.label11.TabIndex = 19;
            this.label11.Text = "Year:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(27, 84);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 17);
            this.label7.TabIndex = 18;
            this.label7.Text = "Name:";
            // 
            // tbGamesYear
            // 
            this.tbGamesYear.Location = new System.Drawing.Point(451, 103);
            this.tbGamesYear.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbGamesYear.Name = "tbGamesYear";
            this.tbGamesYear.Size = new System.Drawing.Size(132, 22);
            this.tbGamesYear.TabIndex = 16;
            // 
            // btnGamesAdd
            // 
            this.btnGamesAdd.Location = new System.Drawing.Point(619, 98);
            this.btnGamesAdd.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnGamesAdd.Name = "btnGamesAdd";
            this.btnGamesAdd.Size = new System.Drawing.Size(124, 28);
            this.btnGamesAdd.TabIndex = 17;
            this.btnGamesAdd.Text = "Add";
            this.btnGamesAdd.UseVisualStyleBackColor = true;
            this.btnGamesAdd.Click += new System.EventHandler(this.btnGamesAdd_Click);
            // 
            // tbGamesGenre
            // 
            this.tbGamesGenre.Location = new System.Drawing.Point(309, 103);
            this.tbGamesGenre.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbGamesGenre.Name = "tbGamesGenre";
            this.tbGamesGenre.Size = new System.Drawing.Size(132, 22);
            this.tbGamesGenre.TabIndex = 15;
            // 
            // tbGamesDev
            // 
            this.tbGamesDev.Location = new System.Drawing.Point(169, 103);
            this.tbGamesDev.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbGamesDev.Name = "tbGamesDev";
            this.tbGamesDev.Size = new System.Drawing.Size(132, 22);
            this.tbGamesDev.TabIndex = 14;
            // 
            // tbGamesName
            // 
            this.tbGamesName.Location = new System.Drawing.Point(27, 103);
            this.tbGamesName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbGamesName.Name = "tbGamesName";
            this.tbGamesName.Size = new System.Drawing.Size(132, 22);
            this.tbGamesName.TabIndex = 13;
            // 
            // listViewGames
            // 
            this.listViewGames.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader11,
            this.columnHeader12});
            this.listViewGames.FullRowSelect = true;
            this.listViewGames.GridLines = true;
            this.listViewGames.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.listViewGames.Location = new System.Drawing.Point(28, 134);
            this.listViewGames.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.listViewGames.Name = "listViewGames";
            this.listViewGames.Scrollable = false;
            this.listViewGames.Size = new System.Drawing.Size(712, 270);
            this.listViewGames.TabIndex = 8;
            this.listViewGames.UseCompatibleStateImageBehavior = false;
            this.listViewGames.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Name";
            this.columnHeader9.Width = 206;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Developer";
            this.columnHeader10.Width = 177;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Genre";
            this.columnHeader11.Width = 107;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "Year";
            this.columnHeader12.Width = 82;
            // 
            // ItemsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 471);
            this.Controls.Add(this.tabControl1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "ItemsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Items";
            this.tabControl1.ResumeLayout(false);
            this.tabPageImportant.ResumeLayout(false);
            this.tabPageImportant.PerformLayout();
            this.tabPageLit.ResumeLayout(false);
            this.tabPageLit.PerformLayout();
            this.tabPageFilm.ResumeLayout(false);
            this.tabPageFilm.PerformLayout();
            this.tabPageMusic.ResumeLayout(false);
            this.tabPageMusic.PerformLayout();
            this.tabPageGames.ResumeLayout(false);
            this.tabPageGames.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPageLit;
        private System.Windows.Forms.TabPage tabPageFilm;
        private System.Windows.Forms.TabPage tabPageMusic;
        private System.Windows.Forms.TabPage tabPageGames;
        private System.Windows.Forms.Button btnLitAdd;
        private System.Windows.Forms.TextBox tbLitYear;
        private System.Windows.Forms.TextBox tbLitGenre;
        private System.Windows.Forms.TextBox tbLitWriter;
        private System.Windows.Forms.ListView listViewLit;
        private System.Windows.Forms.ColumnHeader columnName;
        private System.Windows.Forms.ColumnHeader Writer;
        private System.Windows.Forms.ColumnHeader Period;
        private System.Windows.Forms.ColumnHeader columnYear;
        private System.Windows.Forms.ListView listViewFilm;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.Button btnFilmAdd;
        private System.Windows.Forms.TextBox tbFilmYear;
        private System.Windows.Forms.TextBox tbFilmGenre;
        private System.Windows.Forms.TextBox tbFilmDirector;
        private System.Windows.Forms.TextBox tbFilmName;
        private System.Windows.Forms.ListView listViewMusic;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ListView listViewGames;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.Button btnMusicAdd;
        private System.Windows.Forms.TextBox tbMusicYear;
        private System.Windows.Forms.TextBox tbMusicGenre;
        private System.Windows.Forms.TextBox tbMusicArtist;
        private System.Windows.Forms.TextBox tbMusicName;
        private System.Windows.Forms.Button btnGamesAdd;
        private System.Windows.Forms.TextBox tbGamesYear;
        private System.Windows.Forms.TextBox tbGamesGenre;
        private System.Windows.Forms.TextBox tbGamesDev;
        private System.Windows.Forms.TextBox tbGamesName;
        private System.Windows.Forms.TextBox tbLitName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TabPage tabPageImportant;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ListView listViewImp;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.ColumnHeader columnHeader16;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btnLitDelete;
        private System.Windows.Forms.Button btnLitComp;
        private System.Windows.Forms.Button btnFilm;
        private System.Windows.Forms.Button btnMusicComp;
        private System.Windows.Forms.Button btnGamesComp;
        private System.Windows.Forms.Button btnFilmDelete;
        private System.Windows.Forms.Button btnMusicDelete;
        private System.Windows.Forms.Button btnGamesDelete;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnLitImp;
        private System.Windows.Forms.Button btnFilmImp;
        private System.Windows.Forms.Button btnMusImp;
        private System.Windows.Forms.Button btnGamesImp;
        private System.Windows.Forms.ColumnHeader columnRating;
    }
}

