﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace Killer_App
{
    class Database
    {
        private MySqlConnection connection;

        public Database()
        {
            string connectionString = "Server=localhost; Database=syb; Uid=root; Pwd=Kufverzippe8;";
            connection = new MySqlConnection(connectionString);
        }

        public User UserAuthenticate(string username, string password)
        {
            connection.Open();

            string queryString = "SELECT * " +
                                "FROM killer.user u " +
                                $"WHERE u.username = @username AND u.password = @password;";

            

            using (MySqlCommand command = new MySqlCommand(queryString, connection))
            {
                command.Parameters.Add(new MySqlParameter("@username", username));
                command.Parameters.Add(new MySqlParameter("@password", password));

                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        int id = reader.GetInt32(0);
                        string name = reader[1].ToString();
                        User user = new User(id, name);

                        connection.Close();
                        return user;
                    }
                    else
                    {
                        connection.Close();
                        return null;
                    }
                }
                
            }
            
        }

        public List<Subject> GetSubjects(int userId)
        {
            connection.Open();

            string queryString = "SELECT * " +
                                 "FROM killer.subject s " +
                                 $"WHERE s.userId = {userId};";

            List<Subject> subjects = new List<Subject>();

            using (MySqlCommand command = new MySqlCommand(queryString, connection))
            {
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int id = reader.GetInt32(0);
                        string name = reader[1].ToString();
                        Subject subject = new Subject(id, name);
                        subjects.Add(subject);
                    }
                }
            }
                        connection.Close();
                        return subjects;
            
        }

        public bool AddSubject(int userId, string subjectName)
        {
            connection.Open();
            if(CheckIfDuplicateSubject(subjectName, userId))
            {
                connection.Close();
                return false;
            }
            else
            {
                string queryString = $"INSERT INTO killer.subject (`name`, `userId`) VALUES ('{subjectName}','{userId}');";

                using (MySqlCommand command = new MySqlCommand(queryString, connection))
                {
                    command.ExecuteNonQuery();
                }
            }

            connection.Close();
            return true;

        }

        private bool CheckIfDuplicateSubject(string subject, int userId)
        {
            
            string queryString = "SELECT * " +
                                "FROM killer.subject s " +
                                $"WHERE s.name = \"{subject}\" AND s.userId = \"{userId}\";";

            using (MySqlCommand command = new MySqlCommand(queryString, connection))
            {
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
        }

        public List<Item> GetItems(int userId, Subject subject)
        {
            connection.Open();
            string queryString = "SELECT * " +
                "FROM killer.items i " +
                $"WHERE i.subjectId = \"{subject.Id}\";";

            List<Item> items = new List<Item>();

            using(MySqlCommand command = new MySqlCommand(queryString, connection))
            {
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int id = reader.GetInt32(0);
                        string name = reader[1].ToString();
                        string creator = reader[2].ToString();
                        string genre = reader[3].ToString();
                        int year = reader.GetInt32(4);
                        string sort = reader[5].ToString();
                        string completed = reader[7].ToString();

                        Item item = new Item(id, name, creator, genre, year, sort, completed);
                        items.Add(item);

                    }
                }

            }
            connection.Close();
            return items;
        }

        public void AddItem(string name, string creator, string genre, int year, string sort, Subject subject, User user)
        {
            connection.Open();
            string queryString = $"INSERT INTO killer.items (`name`, `creator`, `genre`, `year`, `sort`, `subjectId`)" +
                                 $" VALUES ('{name}','{creator}','{genre}','{year}','{sort}','{subject.Id}');";

            using (MySqlCommand command = new MySqlCommand(queryString, connection))
            {
                command.ExecuteNonQuery();
            }
            connection.Close();
        }

        public void CompleteItem(Item item)
        {
            connection.Open();
            string queryString = $"UPDATE `killer`.`items` SET `completed` = 'true' WHERE (`id` = \'{item.Id}\');";

            using (MySqlCommand command = new MySqlCommand(queryString, connection))
            {
                command.ExecuteNonQuery();
            }
            connection.Close();
        }

        public void DeleteItem(Item item)
        {
            connection.Open();
            string queryString = $"DELETE FROM `killer`.`items` WHERE (`id` = '{item.Id}');";

            using(MySqlCommand command = new MySqlCommand(queryString, connection))
            {
                command.ExecuteNonQuery();
            }
            connection.Close();
        }

        public void DeleteImportantItem(Item item)
        {
            connection.Open();
            string queryString = $"DELETE FROM `killer`.`important` WHERE(`itemId` = '{item.Id}');";

            using (MySqlCommand command = new MySqlCommand(queryString, connection))
            {
                command.ExecuteNonQuery();
            }
            connection.Close();
        }

        public void DeleteSubject(string subjectName)
        {
            connection.Open();
            string queryString = $"DELETE FROM `killer`.`subject` WHERE (`name` = '{subjectName}');";

            using (MySqlCommand command = new MySqlCommand(queryString, connection))
            {
                command.ExecuteNonQuery();
            }
            connection.Close();
        }

        public void AddToImportant(Item item, Subject subject)
        {
            connection.Open();
            string queryString = $"INSERT INTO `killer`.`important` (`itemId`, `subjectId`) VALUES ('{item.Id}', '{subject.Id}');";

            using (MySqlCommand command = new MySqlCommand(queryString, connection))
            {
                command.ExecuteNonQuery();
            }
            connection.Close();
            
        }

        public List<Item> GetImportantItems(Subject subject)
        {
            List<Item> importantItems = new List<Item>();
            connection.Open();
            string queryString = $"SELECT killer.items.id, killer.items.name, killer.items.creator, killer.items.genre, killer.items.year,  killer.items.sort, killer.items.completed " +
                                  "FROM killer.important " +
                                  "INNER JOIN killer.items ON killer.items.id = killer.important.itemId " +
                                 $"WHERE killer.important.subjectId = {subject.Id};";

            using (MySqlCommand command = new MySqlCommand(queryString, connection))
            {
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int id = reader.GetInt32(0);
                        string name = reader[1].ToString();
                        string creator = reader[2].ToString();
                        string genre = reader[3].ToString();
                        int year = reader.GetInt32(4);
                        string sort = reader[5].ToString();
                        string completed = reader[6].ToString();

                        Item item = new Item(id, name, creator, genre, year, sort, completed);
                        importantItems.Add(item);

                    }
                }

            }
            connection.Close();
            return importantItems;

        } 
        
        public void RateItem(Item item, int rating)
        {

        }




    }
}

