﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Killer_App
{
    public class Item
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Creator { get; set; }
        public string Genre { get; set; }
        public int Year { get; set; }

        public string Sort { get; set; }
        public string Completed { get; set; }
        public Item(int id, string name, string creator, string genre, int year, string sort, string completed)
        {
            Id = id;
            Name = name;
            Creator = creator;
            Genre = genre;
            Year = year;
            Sort = sort;
            Completed = completed;
        }

    }
}
